const Child = (props) => {
  return <h1>Child</h1>;
};
export default Child;
