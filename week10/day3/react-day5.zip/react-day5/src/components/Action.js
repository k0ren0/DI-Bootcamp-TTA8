import Button from "./Button";

const Action = (props) => {
  return (
    <>
      <Button />
    </>
  );
};
export default Action;
