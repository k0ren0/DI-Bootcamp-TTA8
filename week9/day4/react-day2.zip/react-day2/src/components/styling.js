export const userStyle = {
  display: "inline-block",
  textAlign: "center",
  padding: "20px",
  margin: "20px",
  border: "1px solid #ccc",
  borderRadius: "15px",
  backgroundColor: "cyan",
};

export const customerStyle = {
  display: "inline-block",
  textAlign: "center",
  padding: "20px",
  margin: "20px",
  border: "1px solid #ccc",
  borderRadius: "15px",
  backgroundColor: "cyan",
};
