import { Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import Nav from "./components/Nav";
import Info from "./components/Info";
import LoginRegister from "./components/LoginRegister";
import { useState, useContext, createContext } from "react";
import Auth from "./auth/Auth";
import "./App.css";

export const AuthContext = createContext();

function App() {
  const [token, setToken] = useState();
  return (
    <AuthContext.Provider value={{ token, setToken }}>
      <div className='App'>
        <Nav/>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/login' element={<LoginRegister page={"Login"} />} />
          <Route
            path='/register'
            element={<LoginRegister page={"Register"} />}
          />
          <Route path='/info' element={<Auth><Info /></Auth>} />
        </Routes>
      </div>
    </AuthContext.Provider>
  );
}

export default App;
