const Info = (props) => {
  return (
    <>
      <h1>Secure Componet</h1>
    </>
  );
};
export default Info;
