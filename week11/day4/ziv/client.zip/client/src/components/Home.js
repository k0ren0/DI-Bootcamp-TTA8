import { useState, useEffect, useContext } from "react";
import { AuthContext } from "../App";
import axios from "axios";

const Home = (props) => {
  const [users, setUsers] = useState([]);
  const { token } = useContext(AuthContext);

  console.log(token?.token);

  useEffect(() => {
    getusers();
  }, []);

  const getusers = async () => {
    try {
      const response = await axios.get("http://localhost:3001/users", {
        headers: {
          "x-access-token": token?.token,
        },
      });
      setUsers(response.data);
    } catch (error) {}
  };
  return (
    <>
      <h1>Home</h1>
      {users.map((user) => {
        return <div key={user.id}>{user.email}</div>;
      })}
    </>
  );
};
export default Home;
