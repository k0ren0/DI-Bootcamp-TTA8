import TodoList from "./features/todos/TodoList";
import "./App.css";

function App() {
  return (
    <div className='App'>
      <TodoList />
    </div>
  );
}

export default App;
